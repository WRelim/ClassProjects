package com.company;

import java.util.*;
import java.lang.*;
import java.io.*;
import java.time.*;

/**
 * Search Reminder.txt for the weekday
 * (today is found and stored on line 25)
 * Need to grab the name after the day and search the folder for it
 * Ex. Thursday Kitchen
 * "Kitchen.txt"
 */
public class PlannerFinal {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        File plannerFolder = new File("/Users/student/Documents/jetbrains-workspace/ProjectFinal/src/ADHDPlanner");
        boolean folderBoolean = plannerFolder.mkdirs();
        if (folderBoolean) {
            System.out.println("Folder created: " + plannerFolder.getName());
        }
        try {
            FileWriter myWriter = new FileWriter("/Users/student/Documents/jetbrains-workspace/ProjectFinal/src/ADHDPlanner/UserReminderList.txt");
            myWriter.write("");
            myWriter.close();
//            System.out.println("Successfully wrote reminder to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred with the myWriter.");
            e.printStackTrace();
        }
        //today as weekday
        LocalDate today = LocalDate.now();
        DayOfWeek dayOfWeek = today.getDayOfWeek();
        //print reminder file
        String weekday = dayOfWeek.name();
        weekday = capitalize(weekday);
        System.out.println(weekday);
        //this is the problem
        File reminderFile = new File("/Users/student/Documents/jetbrains-workspace/ProjectFinal/src/ADHDPlanner/UserReminderList.txt");
        try {
            Scanner scanFile = new Scanner(reminderFile);
            while (scanFile.hasNextLine()) {
                String foundString = scanFile.nextLine();
                System.out.println(foundString + " " + weekday);
                if (foundString.contains(weekday)) {
                    foundString = foundString.replace(weekday, "");
                    foundString = foundString.replace(" ", "");
                    try {
                        File myObj = new File("/Users/student/Documents/jetbrains-workspace/ProjectFinal/src/ADHDPlanner/"+ foundString + ".txt");
                        Scanner myReader = new Scanner(myObj);
                        while (myReader.hasNextLine()) {
                            String data = myReader.nextLine();
                            System.out.println(data);
                        }
                        myReader.close();
                    } catch (FileNotFoundException e) {
                        System.out.println("An error occurred with foundString.");
                        e.printStackTrace();
                    }
                    System.out.println();
                }
            }
        }
        catch (FileNotFoundException e) {
            System.out.println("Reminder file scan error");
        }
        for (int endProgram = 1; endProgram > 0; ) {
            System.out.println("Choose an option:\n1: Create new task\n2: Look at a previous task\n0: End program");
            endProgram = input.nextInt();
            switch (endProgram) {
                case 0:
                    break;
                case 1:
                    Task task1 = newTask();
                    try {
                        FileWriter myWriter = new FileWriter("/Users/student/Documents/jetbrains-workspace/ProjectFinal/src/ADHDPlanner/" + task1.getName() + ".txt");

                        myWriter.write(task1.toString());
                        myWriter.close();
                        System.out.println("Successfully wrote toString to the file.");
                    } catch (IOException e) {
                        System.out.println("An error occurred with the myWriter.");
                        e.printStackTrace();
                    }
                    if (!task1.getWeekday().equals("None")) {
                        String reminderNote = task1.getWeekday() + " " + task1.getName();
                        try {
                            FileWriter myWriter = new FileWriter("/Users/student/Documents/jetbrains-workspace/ProjectFinal/src/ADHDPlanner/UserReminderList.txt");
                            myWriter.write(reminderNote);
                            myWriter.close();
                            System.out.println("Successfully wrote reminder to the file.");
                        } catch (IOException e) {
                            System.out.println("An error occurred with the myWriter.");
                            e.printStackTrace();
                        }
                    }
                    System.out.println();
                    break;
                case 2:
                    //List the files in directory
                    File[] listOfFiles = plannerFolder.listFiles();
                    for (int i = 0; i < listOfFiles.length; i++) {
                        if (listOfFiles[i].isFile()) {
                            if (listOfFiles[i].getName() != ".DS_Store") {
                                System.out.println("File " + listOfFiles[i].getName());
                            }
                        } else if (listOfFiles[i].isDirectory()) {
                            System.out.println("Directory " + listOfFiles[i].getName());
                        }
                    }

                    System.out.print("Which file would you like to open?: ");
                    String userFileChoice = input.next();
                    if (!userFileChoice.contains(".txt")) {
                        userFileChoice = userFileChoice + ".txt";
                        System.out.println();
                    }
                    //find file in directory and print it to the console
                    try {
                        File myObj = new File("/Users/student/Documents/jetbrains-workspace/ProjectFinal/src/ADHDPlanner/"+ userFileChoice);
                        Scanner myReader = new Scanner(myObj);
                        while (myReader.hasNextLine()) {
                            String data = myReader.nextLine();
                            System.out.println(data);
                        }
                        myReader.close();
                    } catch (FileNotFoundException e) {
                        System.out.println("An error occurred with myReader.");
                        e.printStackTrace();
                    }
                    System.out.println();
                    break;
                default:
                    System.out.println("There is no option assigned to that number.");
            }
        }
    }

    static class Task {
        String name;
        String weekday;
        String description;
        String notes;

        Task() {
            name = "None";
            weekday = "";
            description = "None";
            notes = "None";
        }

        Task(String userName, String userWeekday, String userDescription, String userNotes) {
            this.name = userName;
            this.weekday = capitalize(userWeekday);
            this.description = userDescription;
            this.notes = userNotes;
        }

        String getName() {
            return name;
        }

        void setName(String userName) {
            this.name = capitalize(userName);
        }

        String getDescription() {
            return description;
        }

        void setDescription(String newDescription) {
            this.description = capitalize(newDescription);
        }

        String getNotes() {
            return notes;
        }

        void setNotes(String newNotes) {
            this.notes = capitalize(newNotes);
        }
        String getWeekday() {
            return weekday;
        }
        void setWeekday(String userWeekday) {
            this.weekday = capitalize(userWeekday);
        }

        public String toString() {
            return "Name: " + name + "\tDaily Task: " + weekday + "\nDescription: " + description + "\nNotes: " + notes;
        }
    }
    public static Task newTask() {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the name of the task: ");
        String taskName = input.nextLine();
        System.out.print("Enter a description of the task: ");
        String taskDescription = input.nextLine();
        System.out.print("Enter any notes/reminders about the task: ");
        String taskNotes = input.nextLine();
        System.out.print("What day would you like to be reminded about this task?(If not applicable enter 'None'): ");
        String taskWeekday = input.nextLine();
        Task newTask = new Task(taskName, taskWeekday, taskDescription, taskNotes);

        return newTask;
    }
    public static String capitalize(String str) {
        str = str.toLowerCase();
        String firstLetter = str.substring(0, 1);
        String remainingLetters = str.substring(1);
        firstLetter = firstLetter.toUpperCase();
        return firstLetter + remainingLetters;
    }
    public static String findWeekdaySwitch(String weekday) {
        switch (capitalize(weekday)) {
            case "Monday":
                return "Monday";
            case "Tuesday":
                return "Tuesday";
            case "Wednesday":
                return "Wednesday";
            case "Thursday":
                return "Thursday";
            case "Friday":
                return "Friday";
            case "Saturday":
                return "Saturday";
            case "Sunday":
                return "Sunday";
            default:
                return "None";
        }
    }
}
